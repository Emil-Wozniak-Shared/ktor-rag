package pl

fun interface GreetingService {
    fun sayHello(): String
}
